from rest_framework import viewsets,generics
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Message,Account,Transaction
from .serializers import AccountSerializer,MessageSerializer,TransactionSerializer
from rest_framework.decorators import api_view
from kafka import KafkaProducer
import json
from decimal import Decimal
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect,get_object_or_404
from django.contrib.auth import authenticate, login
from .forms import LoginForm, RegisterForm
from django.contrib import messages




class MessageViewSet(viewsets.ModelViewSet):
    queryset = Message.objects.all()
    serializer_class = MessageSerializer

    def perform_create(self, serializer):
        message = serializer.save()
        producer = KafkaProducer(
            bootstrap_servers='localhost:9092',
            value_serializer=lambda v: json.dumps(v).encode('utf-8')
        )
        producer.send('banking', {
            'sender': message.sender,
            'receiver': message.receiver,
            'content': message.content
        })
        producer.close()


class AccountViewSet(viewsets.ViewSet):
    queryset = Account.objects.all()
    serializer_class = AccountSerializer

    # O Action define o método como válido para os tipos especificados, e as funções tem seus nomes definidos no arquivo urls.py
    @action(detail=False, methods=['post'], url_path='deposit/')
    def deposit(self, request):
        # Identifica a account com a chave_pix fornecida na requisicao
        try:
            chave_pix = request.data.get('chave_pix', None)
            account = Account.objects.get(chave_pix=chave_pix)
        except Account.DoesNotExist:
            return Response({'error': 'Account not found.'}, status=status.HTTP_404_NOT_FOUND)

        # Valida o valor de depósito e o acumula no saldo da account. 
        value = request.data.get('value', None)
        if value is None:
            return Response({'error': 'Please provide a value to deposit.'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            value = Decimal(value)
            account.saldo += value 
            account.save()
            return Response({'message': f'Deposit of {value} successful.'})
        except ValueError:
            return Response({'error': 'Invalid value provided.'}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=False, methods=['post'], url_path='cashout/')
    def cashout(self, request):
        # Identifica a account com a chave_pix fornecida na requisicao
        try:
            chave_pix = request.data.get('chave_pix', None)
            account = Account.objects.get(chave_pix=chave_pix)
        except Account.DoesNotExist:
            return Response({'error': 'Account not found.'}, status=status.HTTP_404_NOT_FOUND)

        # Verifica a senha
        password = request.data.get('password', None)
        if account.senha != password:
            return Response({'error': "Invalid password."}, status=status.HTTP_400_BAD_REQUEST)

        # Valida o valor de cashout 
        value = request.data.get('value', None)
        if value is None:
            return Response({'error': 'Please provide a value to cash out.'}, status=status.HTTP_400_BAD_REQUEST)
        
        # Verifica se existe saldo disponível e o retira da account
        try:
            value = Decimal(value)
            if account.saldo >= value:
                account.saldo -= value
                account.save()
                return Response({'message': f'Cash out of {value} successful.'})
            else:
                return Response({'error': 'Insufficient balance.'}, status=status.HTTP_400_BAD_REQUEST)
        except ValueError:
            return Response({'error': 'Invalid value provided.'}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=['put', 'patch'], url_path='update')
    def update_account(self, request, pk=None):
        print("aqui")
        try:
            account = Account.objects.get(pk=pk)
            print(account)
        except Account.DoesNotExist:
            return Response({'error': 'Account not found.'}, status=status.HTTP_404_NOT_FOUND)

        serializer = AccountSerializer(account, data=request.data, partial=True if request.method == 'PATCH' else False)
        print(serializer)
        if serializer.is_valid():
            serializer.save()
            return Response({'success': 'Account updated successfully.'}, status=status.HTTP_200_OK)
        return Response({'error': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)

@login_required
def welcome(request):
    return render(request, 'home.html')

def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            login = form.cleaned_data['username']
            senha = form.cleaned_data['password']
            try:
                account = Account.objects.get(nome=login, senha=senha)
                return redirect('account_detail', pk=account.pk)
            except Account.DoesNotExist:
                messages.error(request, 'Login ou senha incorretos')
    else:
        form = LoginForm()
    return render(request, 'usuarios/login.html', {'form': form})


def account_detail_view(request, pk):
    # Obtém a account do usuário baseado no pk
    account = get_object_or_404(Account, pk=pk)

    if request.method == 'POST':
        chave_pix = request.POST.get('chave_pix')
        valor = Decimal(request.POST.get('valor', '0.00'))  # Converte o valor para Decimal com valor padrão

        try:
            # Tenta obter a account de destino usando a chave_pix fornecida
            account_destino = Account.objects.get(chave_pix=chave_pix)
        except Account.DoesNotExist:
            # Se a account de destino não for encontrada, exibe uma mensagem de erro e redireciona
            messages.error(request, 'Chave Pix inválida.')
            return redirect('account_detail', pk=pk)

        # Verifica se o saldo da account é suficiente para a transferência
        if account.saldo >= valor:
            # Atualiza os saldos das accounts envolvidas na transferência
            account.saldo -= valor
            account_destino.saldo += valor
            account.valor_transferencia += valor  # Atualiza o valor transferido na account do usuário
            account_destino.valor_recebido += valor  # Atualiza o valor recebido na account de destino
            account.save()
            account_destino.save()
            messages.success(request, 'Transferência realizada com sucesso.')
        else:
            messages.error(request, 'Saldo insuficiente.')

    return render(request, 'usuarios/account_detail.html', {'account': account})

def register_account_view(request):
    form = RegisterForm(request.POST)
    if request.method == 'POST':
        if form.is_valid():
            nome = form.cleaned_data['nome']
            senha = form.cleaned_data['senha']
            chave_pix= form.cleaned_data['chave_pix'] 
            saldo= form.cleaned_data['saldo'] 
            Account.objects.create(nome=nome,
                                    senha=senha,
                                    chave_pix=chave_pix,
                                    status_conta=True,
                                    valor_transferencia=00,
                                    valor_recebido=00,
                                    saldo=saldo
                                    )
            messages.success(request, 'Conta criada com sucesso')
            return redirect('login')

    else:
        form = RegisterForm()
    return render(request, 'usuarios/register_account.html', {'form': form})

@api_view(['POST'])
def transfer_view(request):
    chave_pix_destinatario = request.data.get('chave_pix')
    valor_transferencia = request.data.get('valor')
    conta_id = request.data.get('conta_id')

    if not chave_pix_destinatario or not valor_transferencia or not conta_id:
        return Response({'error': 'Chave Pix, valor e ID da conta são obrigatórios.'}, status=status.HTTP_400_BAD_REQUEST)

    try:
        valor_transferencia = Decimal(valor_transferencia)
    except:
        return Response({'error': 'Valor inválido.'}, status=status.HTTP_400_BAD_REQUEST)

    conta_remetente = get_object_or_404(Account, pk=conta_id)

    if conta_remetente.saldo < valor_transferencia:
        return Response({'error': 'Saldo insuficiente.'}, status=status.HTTP_400_BAD_REQUEST)

    try:
        conta_destinatario = Account.objects.get(chave_pix=chave_pix_destinatario)
    except Account.DoesNotExist:
        return Response({'error': 'Conta destinatária não encontrada.'}, status=status.HTTP_404_NOT_FOUND)

    conta_remetente.saldo -= valor_transferencia
    conta_destinatario.saldo += valor_transferencia
    conta_remetente.save()
    conta_destinatario.save()

    Transaction.objects.create(
        sender=conta_remetente,
        receiver=conta_destinatario,
        amount=valor_transferencia
    )
    return Response({
        'message': 'Transferência realizada com sucesso.',
        'new_balance': f"{conta_remetente.saldo:.2f}"
    })


class AccountTransactionListView(generics.ListAPIView):
    serializer_class = TransactionSerializer

    def get_queryset(self):
        account_id = self.kwargs['account_id']
        print(account_id)
        # Filtra transações onde a conta é o remetente ou o destinatário
        return Transaction.objects.filter(sender_id=account_id) | Transaction.objects.filter(receiver_id=account_id)
    

@api_view(['POST'])
def deposit_view(request):
    account_id = request.data.get('conta_id')
    value = request.data.get('valor')

    if not value or not account_id :
        return Response({'error': 'Valor é obrigatório'}, status=status.HTTP_400_BAD_REQUEST)
    
    try:
        value = Decimal(value)
    except:
        return Response({'error': 'Valor inválido.'}, status=status.HTTP_400_BAD_REQUEST)
    
    conta = get_object_or_404(Account, pk=account_id)

    conta.saldo += value
    conta.save()

    Transaction.objects.create(
        sender=conta,
        receiver=conta,
        amount=value
    )
    return Response({
        'message': 'Depósito realizada com sucesso.',
        'new_balance': f"{conta.saldo:.2f}"
    })