# messaging/admin.py

from django.contrib import admin
from .models import Account, Message

admin.site.register(Account)
admin.site.register(Message)
