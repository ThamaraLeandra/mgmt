from rest_framework import serializers
from .models import Message, Transaction, Account

class MessageSerializer(serializers.ModelSerializer):
    class Meta:
        model = Message
        fields = '__all__'

class AccountSerializer(serializers.ModelSerializer):
    class Meta:
        model = Account
        fields = ['nome', 'saldo', 'chave_pix', 'status_conta', 'data_nascimento', 'email', 'tel', 'cpf']  # Inclua apenas os campos que podem ser atualizados
        extra_kwargs = {
            'senha': {'write_only': True}  # Campo senha é write-only
        }

    def create(self, validated_data):
        account = Account(**validated_data)
        account.set_password(validated_data['senha'])
        account.save()
        return account

    def update(self, instance, validated_data):
        if 'senha' in validated_data:
            instance.set_password(validated_data['senha'])
        return super().update(instance, validated_data)



class TransactionSerializer(serializers.ModelSerializer):
    sender_name = serializers.SerializerMethodField()
    receiver_name = serializers.SerializerMethodField()

    class Meta:
        model = Transaction
        fields = ['sender_name', 'receiver_name', 'amount', 'timestamp']

    def get_sender_name(self, obj):
        return obj.sender.nome

    def get_receiver_name(self, obj):
        return obj.receiver.nome
