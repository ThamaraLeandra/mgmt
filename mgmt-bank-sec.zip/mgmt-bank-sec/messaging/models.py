from django.db import models
from django.contrib.auth.hashers import make_password
from django.utils import timezone
class Message(models.Model):
    sender = models.CharField(max_length=100)
    receiver = models.CharField(max_length=100)
    content = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.sender} to {self.receiver} at {self.timestamp}'

class Account(models.Model):
    username = models.CharField(max_length=100)
    nome = models.CharField(max_length=100)
    senha = models.CharField(max_length=128)  # Senha criptografada
    status_conta = models.BooleanField(default=True)
    data_nascimento = models.DateField
    email = models.CharField(max_length=128)
    tel = models.IntegerField
    cpf = models.CharField(max_length=15)

    # --------------------------------------
    
    #precisa comentar esses valores abaixo após atualizações e jogar eles na class Transaction

    valor_transferencia = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    valor_recebido = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)

    # --------------------------------------

    chave_pix = models.CharField(max_length=100, unique=True)
    saldo = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)

    def set_password(self, raw_password):
        self.senha = make_password(raw_password)
    
    def __str__(self):
        return self.nome

class Transaction(models.Model):
    sender = models.ForeignKey(Account, related_name='sent_transactions', on_delete=models.CASCADE)
    receiver = models.ForeignKey(Account, related_name='received_transactions', on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.sender.nome} -> {self.receiver.nome} : R$ {self.amount}"