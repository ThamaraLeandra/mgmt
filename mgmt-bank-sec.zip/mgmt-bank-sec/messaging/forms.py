# messaging/forms.py
from django import forms
from django.contrib.auth.forms import AuthenticationForm


class LoginForm(forms.Form):
    username = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control form-control-lg', 'placeholder': 'Usuário'}),
        label='Usuário'
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'form-control form-control-lg', 'placeholder': 'Senha'}),
        label='Senha'
    )

class RegisterForm(forms.Form):
    nome = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control form-control-lg', 'placeholder': 'Nome'}),
        label='Nome'
    )
    senha = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'form-control form-control-lg', 'placeholder': 'Senha'}),
        label='Senha'
    )
    chave_pix = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control form-control-lg', 'placeholder': 'Chave pix'}),
        label='Chave pix'
    )
    saldo = forms.CharField(
        widget=forms.NumberInput(attrs={'class': 'form-control form-control-lg', 'placeholder': 'Saldo'}),
        label='Saldo'
    )