import itertools
from django.utils.deprecation import MiddlewareMixin
from django.http import HttpResponseRedirect

class RoundRobinMiddleware(MiddlewareMixin):
    def __init__(self, get_response=None):
        self.get_response = get_response
        self.servers = ['http://localhost:8000', 'http://localhost:8001', 'http://localhost:8002']
        self.server_cycle = itertools.cycle(self.servers)

    def __call__(self, request):
        if (request.method == 'GET'):
            # Verificar se a solicitação está no servidor principal (8000)
            if request.get_host().startswith('localhost:8000'):
                # Verificar se é uma solicitação API e o cookie não está definido
                if request.path.startswith('/api/') and request.COOKIES.get('balanced') != 'true':
                    next_server = next(self.server_cycle)
                    redirect_url = f'{next_server}{request.get_full_path()}'
                    response = HttpResponseRedirect(redirect_url)
                    # Definir o cookie para marcar que o redirecionamento foi feito
                    response.set_cookie('balanced', 'true', max_age=3600, samesite='None', secure=True)
                    return response

            # Processar a solicitação normalmente se não precisar redirecionar
        response = self.get_response(request)
        # Definir o cookie para futuras solicitações
        response.set_cookie('balanced', 'false', max_age=3600, samesite='None', secure=True)
        return response
