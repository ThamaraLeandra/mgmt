from django.http import HttpResponse

def welcome(request):
    return HttpResponse('<h1>Bem-vindo ao MGMT Bank</h1><p>Use /api/ para acessar a API.</p>')
