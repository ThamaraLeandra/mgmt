"""
URL configuration for mgmt_bank project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.views.generic.base import RedirectView
from django.contrib import admin
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from messaging import views
from messaging.views import MessageViewSet, login_view, register_account_view,transfer_view,deposit_view,AccountTransactionListView
from mgmt_bank.views import welcome  
from messaging.views import MessageViewSet, AccountViewSet
from django.contrib.auth import views as auth_views
from messaging import views as messaging_views


router = DefaultRouter()
router.register(r'messages', MessageViewSet)
#router.register(r'accounts', AccountViewSet)
router.register(r'accounts', views.AccountViewSet, basename='account')


urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include(router.urls)),
    path('api/accounts/', AccountViewSet.as_view({'post': 'deposit'})),
    path('api/accounts/deposit/', AccountViewSet.as_view({'post': 'deposit'}), name='account-deposit'),
    path('api/accounts/cashout/', AccountViewSet.as_view({'post': 'cashout'}), name='account-cashout'),
    path('conta/<int:pk>/update/', AccountViewSet.as_view({'put': 'update_account', 'patch': 'update_account'}), name='account-update'),
    path('login/', login_view, name='login'),
    path('conta/<int:pk>/', messaging_views.account_detail_view, name='account_detail'),
    path('', RedirectView.as_view(url='/login/', permanent=False), name='home'),
    path('welcome/', messaging_views.welcome, name='welcome'),  # Adicione esta linha
    path('cadastro/', register_account_view, name='cadastrar_cont'),
    path('api/transfer/', transfer_view, name='transfer'),
    path('api/deposit/', deposit_view, name='deposit'),
    path('api/transactions/<int:account_id>/', AccountTransactionListView.as_view(), name='account-transactions'),
    
    
]
