# mgmt-bank

## Instalação das bibliotecas necessárias

pip install django djangorestframework kafka-python 

se for montar um ambiente virtual 
e der o erro 
 from kafka.vendor.six.moves import range
ModuleNotFoundError: No module named 'kafka.vendor.six.moves'

instale o six 

pip install six

localize o arquivo codec.py '\ve\Lib\site-packages\kafka\codec.py'
toque a linha  from kafka.vendor.six.moves import range
por from six.moves import range

pip install django-cors-headers
pip install psycopg2-binary --user


## Para rodar

python manage.py makemigrations<br>
python manage.py migrate<br>
python manage.py runserver<br>

## Para acessar APIs

http://127.0.0.1:8000/api/<br>
http://127.0.0.1:8000/api/accounts/

## Acessar o admin (para consulta no bd)

http://localhost:8000/admin

### Tem que rodar esse comando antes

python manage.py makemigrations<br>
python manage.py migrate<br>
python manage.py createsuperuser<br>
python manage.py runserver<br>

### 
    As rotas de API para depósito e saque são respectivamente api/accounts/deposit e api/account/cashout
    O método fornecido para ambos os casos deve ser POST, que recebe o JSON { "chave_pix": "", "value": 0 }. (Para o cashout, também deve ser fornecido a chave "password")
